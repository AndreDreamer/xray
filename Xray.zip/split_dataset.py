import splitfolders  # or import split_folders

splitfolders.ratio("databackup", output="databackup", seed=1337, ratio=(.7, .15, .15), group_prefix=None)